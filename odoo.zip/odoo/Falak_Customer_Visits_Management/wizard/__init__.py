# -*- coding: utf-8 -*-
from . import f_cancel_wizard
