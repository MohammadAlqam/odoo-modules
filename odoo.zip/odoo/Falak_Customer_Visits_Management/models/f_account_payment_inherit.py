from odoo import models, fields, api

class FAccountPaymentInherit(models.Model):
    _inherit="account.payment"

    f_visit = fields.Many2one("f.visits" ,string="Visit")
   
    
    def write(self,vals):
        res = super(FAccountPaymentInherit, self).write(vals)
         
        visit = self.env['f.visits'].search([('id','=',self.f_visit.id)],limit=1)
        print('visit.f_payments_total',visit.f_payments_total)
        print('self.amount',self.amount)
        
        if visit:
            visit.sudo().write({'f_payments_total':visit.f_payments_total+self.amount})

        return res
    
    @api.onchange('partner_id')
    def onChangePartnerId(self):
        check = self.env['f.visits'].search([('id','=',self.f_visit.id),('f_customer','=',self.partner_id.id)])
        if not(check):
            self.f_visit=False
            domain = [('f_customer', '=', self.partner_id.id)]
            return {'domain':{'f_visit':domain}}
    
    
        

  
        
            