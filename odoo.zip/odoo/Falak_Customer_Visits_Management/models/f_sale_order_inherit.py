from odoo import models, fields, api
from duplicity.tempdir import default

class FSaleOrderInherit(models.Model):
    _inherit="sale.order"

    f_visit = fields.Many2one("f.visits" ,string="Visit")
    f_counter=fields.Integer(invisible=True)
    f_double_counter = fields.Integer(invisible=True,default=0)
    f_check = fields.Char(invisible=True)
    
    def write(self,vals):
        res = super(FSaleOrderInherit, self).write(vals)
         
        visit = self.env['f.visits'].search([('id','=',self.f_visit.id)],limit=1)
        print('visit',visit)
        print('self.amount_total',self.amount_total)
        if visit:
            visit.sudo().write({'f_sales_total':visit.f_sales_total+self.amount_total})

        return res
            
    @api.onchange('partner_id')
    def onChangePartnerId(self):
        check = self.env['f.visits'].search([('id','=',self.f_visit.id),('f_customer','=',self.partner_id.id)])
        if not(check):
                self.f_visit = False
                domain = [('f_customer', '=', self.partner_id.id)]
                return {'domain':{'f_visit':domain}}

    
    
        
        
        # visit = self.env['f_visits'].serch([('id','=',self.f_visit.id)])
        # customer = visit.f_customer