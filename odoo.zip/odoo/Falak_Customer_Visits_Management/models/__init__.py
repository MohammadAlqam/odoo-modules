# -*- coding: utf-8 -*-
from . import f_customer_route
from . import f_customer_contact_inherit
from . import f_visits
from . import f_sale_order_inherit
from . import f_account_move_inherit
from . import f_account_payment_inherit