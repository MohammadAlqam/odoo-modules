from odoo import models, fields, api


class FCustomerContactInherit(models.Model):
    _inherit="res.partner"
    
    #sequence = fields.Integer(string='Sequence', default=0)
    f_route= fields.Many2one("f.customer.routes" ,string="Route")
