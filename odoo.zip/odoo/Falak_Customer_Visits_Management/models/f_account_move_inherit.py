from odoo import models, fields, api

class FAccountMoveInherit(models.Model):
    _inherit="account.move"

    f_visit = fields.Many2one("f.visits" ,string="Visit")
    
    @api.model
    def write(self,vals):
        res = super(FAccountMoveInherit, self).write(vals)
    
        visit = self.env['f.visits'].search([('id','=',self.f_visit.id)],limit=1)
        print('visit',visit)
        if visit:
            visit.write({'f_invoice_total':visit.f_sales_total+self.amount_total_signed})

        return res
    
    @api.onchange('partner_id')
    def onChangePartnerId(self):
        self.f_visit=False
        domain = [('f_customer', '=', self.partner_id.id)]
        return {'domain':{'f_visit':domain}}