# -*- coding: utf-8 -*-
from odoo import models, fields, api,_
from datetime import datetime, timedelta
from odoo.exceptions import UserError, ValidationError
from datetime import date

class fCustomerTarget(models.Model):
    _name="f.target.setup"
    _rec_name="f_name"
    _description = 'Customer Target'

    f_name = fields.Char(string="Name",required=True)
    f_customer = fields.Many2one("res.partner" ,string="Customer Name",required=True)
    f_from_date = fields.Date(string="From Date",required=True,default=fields.Date.context_today)
    f_to_date = fields.Date(string="To Date",required=True,default=fields.Date.context_today)
    f_target_type = fields.Selection([('rental','Rental'),('sales','Sales')],default='sales',string="Target Type",required=True)
    f_target_amount = fields.Float(string="Target Amount",required=True)
    f_commission_type =fields.Char(string="Commission Type")
    f_commision_value = fields.Float(string="Commission Value",required=True)
    f_commision_value_calculated =fields.Float(string="Commission Value Calculated",readonly=True)
    f_is_calculated = fields.Boolean(string="Is Calculated",readonly=True)
    f_user = fields.Char(string="Calculated By",default=lambda self: self.env.user.name,readonly=True)
    f_user_display = fields.Char(string="Calculated By",readonly=True)
    f_status = fields.Selection([('draft','Draft'),('canceled','Canceled'),('calculated','Calculated'),('confirmed','Confirmed')],default='draft',readonly=True,string="Status")
    f_comment =fields.Text(string="Comment",readonly=True)
    f_calculated_date = fields.Datetime(string="Calculated Date",readonly=True)

    #this function for change domain of Commission type based on target type
    @api.onchange('f_target_type')
    def _f_onchange_type(self):
        
        if (self.f_target_type == 'sales'):
            self.f_commission_type = "percent"
        elif (self.f_target_type == 'rental'):
            self.f_commission_type = "fixedamount"

    @api.onchange('f_to_date','f_from_date')
    def _f_onchange_date(self):
        period = (self.f_to_date - self.f_from_date).days
        if(period<0):
            raise ValidationError(_("From date must be less than to date"))
            
    #this function for calculate the amount of bonus if hitting the target
    def calculate(self):
        for record in self:
            if (record.f_status=='draft'):
                record.f_commision_value_calculated = 0
                sales_bills = record.env['account.move'].search([('state','=','posted'),('date','>=',record.f_from_date),('date','<=',record.f_to_date),('partner_id','=',record.f_customer.id)])
                sales=0
                for sales_bill in sales_bills:
                    sales += sales_bill.amount_total_signed
                if (sales >= record.f_target_amount):
                    if (record.f_target_type == "sales"):
                        record.f_commision_value_calculated = sales*(record.f_commision_value/100)
                    elif(record.f_target_type == "rental"):
                        record.f_commision_value_calculated = record.f_commision_value
                    record.f_status="calculated"
                    record.f_is_calculated=True
                    record.f_comment="Hit the target"
                elif(sales < record.f_target_amount):
                    record.f_status="calculated"
                    record.f_is_calculated=True
                    record.f_comment="Didn't hit the target"
                
                record.f_calculated_date=datetime.now()
                record.f_user_display=record.f_user
            else:
                continue
          
    #this function for Cancel button    
    def cancel(self):
        self.f_status="canceled"
        self.f_is_calculated=False
        self.f_comment=False
        self.f_calculated_date=False
        self.f_commision_value_calculated=0
        self.f_user_display=False
        
    #this function for Draft button  
    def reset_to_draft(self):
        self.f_status="draft"
        self.f_is_calculated=False
        self.f_comment=False
        self.f_calculated_date=False
        self.f_commision_value_calculated=0
        self.f_user_display=False
        
    def confirm(self):
        self.f_status="confirmed"
        
        
        
        