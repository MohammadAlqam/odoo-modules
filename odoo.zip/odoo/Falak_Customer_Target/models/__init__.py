# -*- coding: utf-8 -*-

from . import f_target_setup