# -*- coding: utf-8 -*-
# from odoo import http


# class FalakCustomerTarget(http.Controller):
#     @http.route('/falak__customer__target/falak__customer__target/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/falak__customer__target/falak__customer__target/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('falak__customer__target.listing', {
#             'root': '/falak__customer__target/falak__customer__target',
#             'objects': http.request.env['falak__customer__target.falak__customer__target'].search([]),
#         })

#     @http.route('/falak__customer__target/falak__customer__target/objects/<model("falak__customer__target.falak__customer__target"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('falak__customer__target.object', {
#             'object': obj
#         })
